import { randomSuperhero } from 'superheroes';

console.log(`I am ${randomSuperhero()}`);

