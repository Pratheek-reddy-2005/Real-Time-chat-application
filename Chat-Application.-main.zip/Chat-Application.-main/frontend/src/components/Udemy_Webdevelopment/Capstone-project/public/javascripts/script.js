var box = document.querySelector(".flexit");
